╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║              GRÁFICAS DE ANÁLISIS DE EMPATÍA DE CÓDIGO              ║
║                      Code Empathizer v2.2.2                          ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝

CONTENIDO DEL ARCHIVO

Este archivo ZIP contiene todas las gráficas generadas del análisis de
empatía de código entre repositorios en formato PNG de alta calidad.

ARCHIVOS INCLUIDOS:

1. grafica_radar_20251125_124531.png
   └─ Gráfica tipo radar que muestra la comparación general entre
      empresa y candidato en todas las categorías

2. grafica_barras_20251125_124531.png
   └─ Gráfica de barras comparativas por categoría individual

3. grafica_categorias_20251125_124531.png
   └─ Gráfica de líneas mostrando evolución y diferencias

4. grafica_distribucion_20251125_124531.png
   └─ Gráficas circulares (pie charts) de distribución de puntuaciones

5. grafica_heatmap_20251125_124531.png
   └─ Mapa de calor mostrando intensidad de métricas

CÓMO USAR ESTAS GRÁFICAS:

• Abrir con cualquier visor de imágenes
• Insertar en presentaciones (PowerPoint, Google Slides, etc.)
• Incluir en documentos (Word, PDF, etc.)
• Compartir directamente por email o mensajería
• Publicar en documentación técnica

RESOLUCIÓN:

Todas las gráficas están generadas en alta resolución (300 DPI)
para garantizar calidad profesional en impresión y presentaciones.

INFORMACIÓN TÉCNICA:

• Formato: PNG
• Resolución: 300 DPI
• Generado: 25/11/2025 12:45:33
• Herramienta: Code Empathizer v2.2.2

═══════════════════════════════════════════════════════════════════════

Para más información sobre Code Empathizer:
https://github.com/686f6c61/Code-Empathizer

Licencia: MIT
Autor: https://github.com/686f6c61
